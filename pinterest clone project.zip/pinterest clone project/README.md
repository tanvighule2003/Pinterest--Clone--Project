# Pinterestclone
[![Netlify Status](https://api.netlify.com/api/v1/badges/e98917f9-aecb-410b-abe3-bc9accde1394/deploy-status)
https://pinterestclone-yk.netlify.app/